# Lakshya Khaki V30 — Firebase Online Community

V30 upgrades the Community from local/demo UI to a real Firebase-backed foundation.

## Included
- Firebase Email/Password login + sign-up
- User profile document in `users/{uid}`
- Realtime Firestore community feed (`posts`)
- Create posts (500 character limit)
- Like/unlike with transaction-backed `likedBy` + `likes`
- Realtime replies in `posts/{postId}/replies`
- Reply counter
- Own-post delete
- Logout
- Basic Firestore security rules in `firestore.rules`

## Firebase Console steps
1. Firebase Console → Authentication → Sign-in method → enable **Email/Password**.
2. Firebase Console → Firestore Database → Create database.
3. Publish the provided `firestore.rules` rules.
4. Keep `app/google-services.json` for the Firebase project already connected to package `com.lakshyakhaki.app`.

## Important
- `google-services.json` connects the Android app to the Firebase project; Authentication and Firestore still need to be enabled in the Firebase Console.
- The feed requires internet access.
- The rules intentionally require signed-in users for community access.
