# Lakshya Khaki V43 — Personalized Home

V43 upgrades the Home dashboard using the profile data collected during onboarding.

## Added
- Personalized greeting using the user name
- Target recruitment, district and target year chips
- Goal shown on Home
- Goal-based “आजचा Focus” card
- Focus button routes to Study or Ground based on the selected goal
- Existing Home progress, community, notifications and daily affairs remain in place

## Firebase
Reads `users/{uid}` fields: `name`, `district`, `targetRecruitment`, `targetYear`, `goal`.
No password is read or stored here.

## Version
4.3.0 / versionCode 39

Build note: source changes were packaged, but Android SDK/Gradle build was not available in this environment for a full APK compile verification.
