# Lakshya Khaki V39 — Cloudinary configured

## Android credentials configured
- Cloud name: `p6onmswi`
- Unsigned upload preset: `Lakshya preset`
- No Cloudinary API secret is included in the Android app.

## Image flow
1. User selects an image.
2. Android sends the original bytes directly to Cloudinary using the unsigned preset.
3. The upload response provides `secure_url` and `public_id`.
4. The post is saved in Firestore with `imageUrl` and `imagePublicId`.
5. The same media metadata is saved in Realtime Database at `postMedia/{postId}`.

The Android upload code does not resize, recompress, or otherwise transform the image. Keep the Cloudinary unsigned preset free of incoming transformations if storage of the original uploaded file is required.

## Delete flow
The Android app calls `DELETE_BACKEND_URL` with the `public_id`. The backend calls Cloudinary's authenticated destroy API using the API secret, then the Android app removes the Firestore post and Realtime Database metadata.

Configure this in `app/build.gradle.kts`:

```kotlin
buildConfigField("String", "DELETE_BACKEND_URL", "\"https://YOUR-BACKEND-DOMAIN/delete-media\"")
```

Do not put `CLOUDINARY_API_SECRET` in Android code.

## Backend

```bash
cd backend
npm install

# Set these environment variables before starting:
# CLOUDINARY_CLOUD_NAME=p6onmswi
# CLOUDINARY_API_KEY=...
# CLOUDINARY_API_SECRET=...

npm start
```

Then set the Android `DELETE_BACKEND_URL` to the public HTTPS endpoint of this backend, for example:

`https://your-domain.example/delete-media`

The backend accepts either JSON body or query parameters:

```json
{
  "public_id": "lakshya_khaki/posts/example",
  "resource_type": "image"
}
```

## Important security note
An unsigned upload preset is visible in client code and can be used by clients that know its name. Keep the preset restricted (for example allowed image formats and a sensible max file size) and rotate the preset if it is abused. Never expose the Cloudinary API secret in the APK.
