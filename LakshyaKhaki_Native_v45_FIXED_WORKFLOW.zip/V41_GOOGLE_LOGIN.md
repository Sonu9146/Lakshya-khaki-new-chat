# Lakshya Khaki V41 — Google Login

V41 upgrades the existing Intro/Login flow with real Firebase Google Sign-In using Android Credential Manager.

## Included
- Google button now launches the native Google account credential flow.
- Google ID token is exchanged for a Firebase Auth credential.
- Google profile name/email/photo are merged into `users/{uid}`.
- Existing email/password login, signup and password reset remain.
- Firebase BoM updated to 34.19.0.

## Firebase setup required
1. Firebase Console → Authentication → Sign-in method → enable **Google**.
2. Firebase Console → Project settings → Your Android app → add the app SHA-1 fingerprint.
3. After enabling Google, download the **updated `google-services.json`** and replace `app/google-services.json`. The updated file contains the OAuth client information needed by Google Sign-In.
4. The generated Web application OAuth 2.0 client ID must be used in `app/src/main/res/values/strings.xml` as `default_web_client_id`.
5. Rebuild the app.

The official Firebase Android guide currently recommends Credential Manager + `googleid` for Google authentication.

## Important
Google Sign-In will not work until the Firebase Google provider, SHA-1, updated `google-services.json`, and Web client ID are configured. Email/password authentication continues to work independently.
