# Lakshya Khaki V45

V45 packages the complete V44 Android source with the planned preparation modules already present in the source (Study Planner, Mistake Book, Analytics, Smart Practice, Daily Affairs, Ground tracking, Community, notifications and personalized Home), plus version/build alignment for the current Firebase Kotlin metadata.

Build configuration:
- Android Gradle Plugin 8.7.0
- Gradle 8.9
- Kotlin 2.3.0
- KSP 2.3.4
- Java/JVM 17
- versionCode 41 / versionName 4.5.0

GitHub Actions builds the checked-out project directly; no nested project ZIP extraction is required.
