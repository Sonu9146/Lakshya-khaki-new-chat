# V36 — Post Detail, Threaded Replies & Sharing

Version: 3.8.0 (versionCode 33)

- Added dedicated Post Details screen.
- Added threaded replies using `parentId`.
- Added Reply-to UI.
- Added Share post using Android share sheet.
- Added Copy post text.
- Existing Firebase likes, saves, reports, follows and notifications remain.
- Existing replies without `parentId` remain top-level.

Note: source is prepared for Android Studio; exact build was not run in this environment because Android SDK/Gradle build tooling is unavailable here.
