# Lakshya Khaki V42 — Profile Onboarding

V42 adds the post-login onboarding flow.

Flow:
`Intro → Welcome → Login/Signup/Google → Onboarding → Home`

Collected fields:
- Name
- District
- Target recruitment: Maharashtra Police / Pune City / Pune Gramin / Pimpri-Chinchwad
- Target year: 2026–2029
- Main goal

Saved to `users/{uid}` in Firestore with `onboardingComplete: true`. Existing users who are signed in but have not completed onboarding are routed to onboarding from the intro screen.

No password is stored in Firestore. Firebase Authentication continues to handle authentication.
