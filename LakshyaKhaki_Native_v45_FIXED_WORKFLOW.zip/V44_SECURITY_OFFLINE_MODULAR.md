# Lakshya Khaki V44 — Security, Offline-first & Architecture Foundation

## 1. Firebase security
- Firestore requires authentication for user/community reads and writes.
- Users cannot modify `role`/`admin` fields.
- Community posts/replies are owner/auth constrained.
- Realtime Database is deny-by-default outside `postMedia` and requires `auth != null`.
- Replace `PUT_YOUR_ADMIN_FIREBASE_UID_HERE` with the real admin UID before production.
- Never publish Firebase service-account private keys.

## 2. Offline-first community outbox
- Text posts, likes/unlikes and replies are first written to Room `community_outbox`.
- WorkManager syncs the outbox when network is available.
- Post/reply document IDs are deterministic (`offline_<outboxId>`) to reduce duplicate retries.
- Like actions store the desired state instead of a toggle, making retries safer.
- Image posts still require network for the Cloudinary upload; they are not falsely marked offline-ready.
- Quiz and ground records continue to use Room locally.

## 3. Clean architecture foundation
- `data/` now contains Room entities/DAO plus `CommunityOfflineRepository` and `CommunitySyncWorker`.
- UI remains in `MainActivity.kt` for this incremental migration. Full screen-by-screen MVVM extraction should be done in a later refactor so behaviour is not broken.

## 4. Release hardening
- Release builds use R8 (`isMinifyEnabled = true`) and resource shrinking.
- `proguard-android-optimize.txt` plus `app/proguard-rules.pro` are enabled for release.
- Version: 4.4.0 / versionCode 40.
