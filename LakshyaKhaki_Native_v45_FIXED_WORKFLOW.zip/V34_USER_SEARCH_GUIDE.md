# Lakshya Khaki V34 – User Search & Follow Lists

## Added
- Community user search by display name/email.
- Public community profile navigation.
- Followers list.
- Following list.
- Tappable Followers/Following counts on profiles.
- Find Users action from community profile.
- Uses existing Firestore users/{uid}/followers and users/{uid}/following collections.

## Version
- versionName: 3.6.0
- versionCode: 31

## Note
Search currently loads a capped set of users and filters locally; for a large production community, server-side search/indexing should be added later.
