# Lakshya Khaki release R8 rules
# Keep Firebase/Room generated model metadata that can be reflected at runtime.
-keepattributes *Annotation*
-keepattributes Signature
-keep class com.google.firebase.** { *; }
-keep class com.lakshyakhaki.app.data.** { *; }
-dontwarn org.conscrypt.**
