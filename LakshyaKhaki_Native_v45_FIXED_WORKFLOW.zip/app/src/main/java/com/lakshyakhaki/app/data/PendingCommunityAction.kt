package com.lakshyakhaki.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "community_outbox")
data class PendingCommunityAction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uid: String,
    val type: String,
    val postId: String = "",
    val text: String = "",
    val parentId: String = "",
    val authorName: String = "",
    val desiredLiked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val attempts: Int = 0
)
